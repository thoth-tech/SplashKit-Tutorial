﻿**introduction to SKM**

`   `**- What is SplashKit Manager (SKM)?**

SplashKit Manager, also known as SKM, is a Command Line Interface (CLI) and Graphical User Interface (GUI) tool designed for installing and managing SplashKit. SplashKit itself is described as a beginner's all-purpose software toolkit. SKM facilitates the installation and management of SplashKit, along with the creation, building, and running of SplashKit projects]

To install SKM, users can utilize installation scripts provided, such as the one available at this link: 

(<https://raw.githubusercontent.com/splashkit/skm/master/install-scripts/skm-install.sh>).

` `The installation involves opening a terminal and ensuring the presence of necessary tools like **curl** and **git**.

Potential issues that the new users may encounter during installation process, one of the examples can be a discussion in a Reddit thread where a user faced challenges with the recognition of the '.splashkit' folder by the terminal. Web link: (https://www.reddit.com/r/linuxquestions/comments/lx5pn6/issue\_installing\_splashkit/).


`   `- **Installation and setup**

**SplashKit Installation guide(link): https://splashkit.io/articles/installation/**

![A screenshot of a computer

Description automatically generated](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.001.png)

![A screenshot of a computer

Description automatically generated](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.002.png)

**Note: Following tutorial is only for windows, for installation on other types, please refer back to “ <https://splashkit.io/installation>”**

**Step 1. Install the MSYS2 terminal**

1. Download the correct version of MSYS (32bit or 64bit depending on your computer).
1. Run the installer and follow the installation wizard, with default values. (Do not install in a location with spaces in the path!)

**Step 2. Install SplashKit SDK**

1. **Start by installing the git client. This will be used to download and update SplashKit. Run the following at the Terminal:**

![A blue and white text on a black background

Description automatically generated](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.003.png)

pacman -S git --noconfirm --disable-download-timeout

1. **In your MSYS2 Terminal, paste and run the following line**

![](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.004.png)

bash <(curl -s <https://raw.githubusercontent.com/splashkit/skm/master/install-scripts/skm-install.sh>)

1. **Restart the terminal and execute skm to test it was successfully installed.**

skm

Once Successful with input skm, you should see following message:

![](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.005.png)

**Step 3. Install Visual Studio Code**

1. Download Visual Studio Code
1. Run the installer

**Step 4. Install language tools**

1. For C#, download Dotnet core tools.
1. For C++, download g++ for msys2

**Special installation(for future updates):**

**SKM Global Commands(windows):**

g++ ${APP\_PATH}/test.cpp -L /usr/local/lib -lSplashKit -I /usr/local/include/ /usr/local/lib/libSplashKitCPP.a -o ${APP\_PATH}/test

**Working with SKM Commands**

`   `- **Overview of the SKM command structure**

The SplashKit Manager (SKM) serves as a powerful command-line interface for installing and managing SplashKit projects and resources.

Common terminal used for initial skm commands: ![](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.006.png)

`   `- **Basic usage: skm [command] [arguments]**

![](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.007.png)

- **skm:** Initiates the SplashKit Manager command.
- **[command]:** Specifies the action to be performed, such as installing, managing, or running a SplashKit project.
- **[arguments]:** Additional parameters or details required for the specified command.

**Examples of skm basic usage:**

1. ![](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.008.png)

This will let you install the splashkit library onto your system.

1. ![](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.009.png)

This is the first step of coding, by creating a new splashkit project named ”my\_project.”, change “my\_project” to any names desirable.

1. ![A black background with white text

Description automatically generated](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.010.png)

This will allow you to build and runs the specific splashkit project, in this case is the name “my\_project” from above.

1. ![](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.011.png)

This will display a list of installed splashkit packages.

1\. **Understanding SKM Commands**

1. **skm new [language]:**
   1. *Function:* create a new SplashKit Project in the current folder(with the specific language).
   1. *Example:* **skm new c++**
   1. *Use Cases:* perform necessary installation steps to build the SplashKit Library locally. 
1. **skm python3:**
   1. *Function:* run python3 with SplashKit settings.
   1. *Example:* **skm python3**
   1. *Use Cases:* initiating python3 under SplashKit.
1. **skm resources:**
   1. *Function:* create the resources folders used by splashkit for resources.
   1. *Example:* **skm resources**
1. **skm revert:**
   1. *Function:* downgrade to earlier versions of splashkit.
   1. *Example:* **skm revert 1 (revert back to version prior to C++17 features)**
   1. *Use Cases:* if there exist issues in current version you can downgrade.
1. **skm update:**
   1. *Function:* Checks and updates a specific SplashKit package to its latest version.
   1. *Example:* **skm update** 
   1. *Use Cases:* Keeping libraries up to date with the latest features.
1. **skm help [command]:**
   1. *Function:* Displays help information for a specific command.
   1. *Example:* **skm help clang++/python3**
   1. *Use Cases:* Accessing command-specific documentation.
1. **skm clang++/g++:**
   1. *Function:* runs clang++/g++ compiler.
   1. *Example:* **skm clang++/g++**
   1. *Use Cases:* running specific complier.
1. **skm dotnet**
   1. *Function:* run the dotnet command line tool for splashkit.
   1. *Example:* **skm dotnet help/skm dotnet info**
   1. *Use Cases:* dotnet [options]/[path-to-application].
1. **skm linux**
   1. *Function:* run linux distribution specific commands – namely linux install
   1. *Example:* **skm link install**
   1. *Use Cases:* installing linux, and following command lines.
1. **skm uninstall**
   1. Uninstalls SplashKit

**Integration with IDEs and build systems**

`   `**Visual Studio Code Integration:**

1. **Install Extension:**
   1. Open VisualStudioCode.
   1. Navigate to the Extensions view (**Ctrl+Shift+X**).
   1. Search for "C#" or “C++” and install the C#/C++ extension.
1. Create a SplashKit project
   1. Use SKM to create a new SplashKit project for example c++:
   1. Replace the following path to your path

      ![A screenshot of a computer program

Description automatically generated](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.012.png)

**Build System Integration:**

**CMake Example (C++ Project):**

1. **Create CMakeLists.txt:**
   1. ` `**Create a CMakeLists.txt file in your project root. Assume your source files are in the 'src' folder.**
   1. ![A screen shot of a computer program

Description automatically generated](Aspose.Words.a80a528d-f145-4598-b930-f2a23f8de5e5.013.png)
1. Build project:
   1. Use SKM to buildthe project such as cmake:
   1. skm build cpp MySplashKitProject
1. run project:
   1. skm run cpp MySplashKitProject
